===========
UMC modules
===========

.. automodule:: univention.management.console.modules
	:members:
	:undoc-members:
	:show-inheritance:

.. automodule:: univention.management.console.modules.decorators
	:members:
	:undoc-members:
	:show-inheritance:

.. automodule:: univention.management.console.modules.sanitizers
	:members:
	:undoc-members:
	:show-inheritance:

.. automodule:: univention.management.console.modules.mixins
	:members:
	:undoc-members:
	:show-inheritance:

